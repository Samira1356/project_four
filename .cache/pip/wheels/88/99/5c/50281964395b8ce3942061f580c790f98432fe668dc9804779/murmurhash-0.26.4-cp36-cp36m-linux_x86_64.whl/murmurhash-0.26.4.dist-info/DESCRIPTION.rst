.. image:: https://travis-ci.org/spacy-io/murmurhash.svg?branch=master
    :target: https://travis-ci.org/spacy-io/murmurhash

Cython bindings for MurmurHash2
-------------------------------


