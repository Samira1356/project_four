__version__ = '0.8.2'
__toolz_version__ = '0.8.2'
